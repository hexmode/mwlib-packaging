~~~~~~~~~~~~~~~~~~~
Internals
~~~~~~~~~~~~~~~~~~~

The following section describes some of the internals of mwlib. Only
read this if you plan to extend mwlib's functionality.

.. include:: writers.rst
.. include:: metabook.rst
