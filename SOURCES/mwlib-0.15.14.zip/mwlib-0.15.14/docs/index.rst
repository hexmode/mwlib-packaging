.. mwlib documentation master file, created by
   sphinx-quickstart on Mon Nov 14 17:53:19 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to mwlib's documentation!
=================================

Contents:

.. toctree::
   :maxdepth: 2

   basics
   installation
   renderserver
   commands
   internals
   collection
   changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

