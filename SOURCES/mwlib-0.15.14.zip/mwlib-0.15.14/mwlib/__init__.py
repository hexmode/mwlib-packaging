
# Copyright (c) 2007-2009 PediaPress GmbH
# See README.rst for additional licensing information.

import pkg_resources
pkg_resources.declare_namespace("mwlib")
