
# Copyright (c) 2007-2009 PediaPress GmbH
# See README.rst for additional licensing information.

import os
import mwlib.log
DEBUG = "DEBUG_EXPANDER" in os.environ
log = mwlib.log.Log("expander")
