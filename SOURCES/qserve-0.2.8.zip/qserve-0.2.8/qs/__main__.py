if __name__ == "__main__":
    from qs import qserve
    qserve.main()
