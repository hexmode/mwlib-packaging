.. -*- mode: rst; coding: utf-8 -*-

======================================================================
mwlib.ext - external dependencies needed by mwlib
======================================================================

mwlib.ext provides external dependencies needed by the mwlib
library. It contains a copy of reportlab_, which is a BSD licensed pdf
generation library.

Please visit http://code.pediapress.com/ for further information.


.. _reportlab: http://www.reportlab.org
