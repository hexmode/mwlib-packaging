
# Copyright (c) 2007-2008 PediaPress GmbH
# See README.txt for additional licensing information.

import pkg_resources
pkg_resources.declare_namespace("mwlib")
