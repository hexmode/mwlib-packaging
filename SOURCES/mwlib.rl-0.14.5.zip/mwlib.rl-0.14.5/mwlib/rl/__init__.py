try:
    import mwlib.ext #try to use bundled version of reportlab
except ImportError:
    pass
